
export default function App() {
  return (
    <div style={{ textAlign: 'center', padding: '40px' }}>
      <h1>Industry Diagnosis Frontend</h1>
      <p>Connected to the Flask backend on Render.</p>
    </div>
  );
}
